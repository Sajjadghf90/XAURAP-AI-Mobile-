"""Auditable computational approximations; not a faithful implementation of every named trading school."""
from __future__ import annotations
import math
import pandas as pd

METHODS = {
 'EMA_TREND': ('روند EMA', 'قواعد مستقیم'),
 'BREAKOUT_20': ('شکست ۲۰ کندل', 'قواعد مستقیم'),
 'MEAN_REVERSION_BB': ('برگشت به میانگین باند بولینگر', 'قواعد مستقیم'),
 'RSI_REVERSION': ('برگشت افراط RSI', 'قواعد مستقیم'),
 'LIQUIDITY_SWEEP': ('جاروب نقدینگی — تقریب SMC/ICT', 'تقریبی'),
 'FVG_DISPLACEMENT': ('عدم تعادل تازه FVG', 'تقریبی'),
 'VWAP_RECLAIM': ('بازپس‌گیری VWAP غلتان', 'تقریبی'),
 'MOMENTUM': ('حرکت شتاب‌دار', 'قواعد مستقیم'),
 'CANDLE_REVERSAL': ('الگوی برگشتی کندلی', 'قواعد مستقیم'),
 'RANGE_EDGE': ('لبه رنج و بازگشت', 'قواعد مستقیم'),
}
# These are kept visible in the capability manifest but NOT passed off as runnable ML strategies.
EXTERNAL_ONLY = ['DOM','FOOTPRINT','TAPE_READING','HFT','STAT_ARB_MULTI_ASSET','OPTIONS_FLOW','REAL_ORDER_BOOK','FULL_COMEX_VOLUME_PROFILE','BROKER_POSITIONING']

def candidates(r: pd.Series) -> list[tuple[str,int]]:
    def f(key):
        try: return float(r[key])
        except (ValueError,KeyError,TypeError): return math.nan
    c,o,hi,lo = f('close'),f('open'),f('high'),f('low')
    e9,e21,e55 = f('ema9'),f('ema21'),f('ema55')
    rsi,cp,body = f('rsi14'),f('close_pos'),f('body_pct')
    ret3,br = f('ret3_atr'),f('bar_range_atr')
    b = []
    def add(key,direction): b.append((key,direction))
    if e9>e21>e55 and c>e9 and c>o: add('EMA_TREND',1)
    if e9<e21<e55 and c<e9 and c<o: add('EMA_TREND',-1)
    if c>f('hi20prev') and body>=0.50: add('BREAKOUT_20',1)
    if c<f('lo20prev') and body>=0.50: add('BREAKOUT_20',-1)
    if f('bb_z')<-1.6 and cp>=0.60: add('MEAN_REVERSION_BB',1)
    if f('bb_z')>1.6 and cp<=0.40: add('MEAN_REVERSION_BB',-1)
    if rsi<35 and cp>=0.60: add('RSI_REVERSION',1)
    if rsi>65 and cp<=0.40: add('RSI_REVERSION',-1)
    if lo<f('lo20prev') and c>f('lo20prev') and cp>=0.60: add('LIQUIDITY_SWEEP',1)
    if hi>f('hi20prev') and c<f('hi20prev') and cp<=0.40: add('LIQUIDITY_SWEEP',-1)
    if r.get('fvg_bull',False) and c>o and body>=0.50: add('FVG_DISPLACEMENT',1)
    if r.get('fvg_bear',False) and c<o and body>=0.50: add('FVG_DISPLACEMENT',-1)
    if f('prev_close')<=f('prev_vwap') and c>f('rolling_vwap') and body>=0.45: add('VWAP_RECLAIM',1)
    if f('prev_close')>=f('prev_vwap') and c<f('rolling_vwap') and body>=0.45: add('VWAP_RECLAIM',-1)
    if ret3>1.2 and body>=0.60 and rsi>55: add('MOMENTUM',1)
    if ret3<-1.2 and body>=0.60 and rsi<45: add('MOMENTUM',-1)
    engulf_bull = f('prev_close')<f('prev_open') and c>o and c>=f('prev_open') and o<=f('prev_close')
    engulf_bear = f('prev_close')>f('prev_open') and c<o and c<=f('prev_open') and o>=f('prev_close')
    if engulf_bull or (f('lower_wick')>0.52 and cp>0.72 and c>f('ema21')-f('atr')):add('CANDLE_REVERSAL',1)
    if engulf_bear or (f('upper_wick')>0.52 and cp<0.28 and c<f('ema21')+f('atr')):add('CANDLE_REVERSAL',-1)
    if f('range_location')<0.13 and cp>0.63 and br<2.3: add('RANGE_EDGE',1)
    if f('range_location')>0.87 and cp<0.37 and br<2.3: add('RANGE_EDGE',-1)
    return b


def evaluate_pine_votes(raw:pd.DataFrame, spread_price:float=0.30,horizon:int=8,minimum_events:int=15):
    """Historical matured outcome tracker for all 36 methods that Pine can vote on.

    The 9 external-only methods are NEVER selected. Posterior estimates are descriptive,
    not calibrated ML probabilities. Only future bars already observed at evaluation time
    can settle a past signal.
    """
    import json
    from pathlib import Path
    from .features import normalize_ohlcv,features_from_raw
    from .model import RISK_ATR,REWARD_R,bracket_outcome
    if 'method_votes' not in raw or len(raw)<80:
        return {'active':False,'reason':'No sufficient complete Pine vote history'}
    d=features_from_raw(normalize_ohlcv(raw))
    registry=json.loads((Path(__file__).parent/'methods_45_manifest.json').read_text(encoding='utf-8'))
    import numpy as np
    votes=[]
    for val in d.method_votes.fillna(''):
        chunks=str(val).split(';')
        votes.append([int(x) for x in chunks] if len(chunks)==45 and all(x in ('-1','0','1') for x in chunks) else [0]*45)
    vote_mat=np.asarray(votes,dtype=np.int8)
    active=vote_mat[-1]
    nbar=len(d)
    # Precompute realized bracket outcomes with only matured future bars (vectorized).
    last_i=nbar-horizon
    idx=np.arange(75,last_i)
    entry=d.close.to_numpy(dtype=float)[idx]
    risk=d.atr.to_numpy(dtype=float)[idx]*RISK_ATR
    highs=d.high.to_numpy(dtype=float)
    lows=d.low.to_numpy(dtype=float)
    upwin=np.zeros(len(idx),dtype=np.int8)
    downwin=np.zeros(len(idx),dtype=np.int8)
    updone=np.zeros(len(idx),dtype=bool)
    downdone=np.zeros(len(idx),dtype=bool)
    for shift in range(1,horizon+1):
        hi=highs[idx+shift];lo=lows[idx+shift]
        long_stop=lo <= entry-risk
        long_target=hi >= entry+risk*REWARD_R
        short_stop=hi >= entry+risk
        short_target=lo <= entry-risk*REWARD_R
        upwin[(~updone)&(~long_stop)&long_target]=1
        downwin[(~downdone)&(~short_stop)&short_target]=1
        updone |= long_stop|long_target
        downdone |= short_stop|short_target
    scored=[]
    for m in registry:
        col=m['index']
        if m['pine_status']=='external' or active[col]==0: continue
        side_history=vote_mat[75:last_i,col]
        n=int(np.count_nonzero(side_history))
        if n<minimum_events:continue
        w=int(np.sum(np.where(side_history==1,upwin,np.where(side_history==-1,downwin,0))))
        posterior=(w+2)/(n+4)
        atr=float(d.iloc[-1].atr)
        cost=max(0,spread_price)/max(atr*RISK_ATR,1e-9)
        er=posterior*REWARD_R-(1-posterior)-cost
        scored.append({'method':m['name'],'direction':'BUY' if active[col]==1 else 'SELL',
                       'count_matured':n,'wins_matured':w,
                       'shrunken_success_rate':round(posterior,4),
                       'estimated_R_after_spread_proxy':round(er,4),
                       'representation':m['pine_status']})
    scored.sort(key=lambda v:v['estimated_R_after_spread_proxy'],reverse=True)
    if not scored or scored[0]['estimated_R_after_spread_proxy']<=0:
        return {'active':False,'reason':'No current Pine method has sufficient matured positive historical expectancy','tested':scored[:5]}
    return {'active':True,'method':scored[0]['method'],'direction':scored[0]['direction'],
           'estimated_R_after_spread_proxy':scored[0]['estimated_R_after_spread_proxy'],
           'matured_events':scored[0]['count_matured'], 'tested':scored[:5],
           'warning':'Online descriptive Pine vote outcomes; not a separately validated ML prediction.'}
