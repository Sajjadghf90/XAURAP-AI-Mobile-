"""Causal features based exclusively on current or earlier completed candles."""
from __future__ import annotations
import numpy as np
import pandas as pd

FEATURE_COLUMNS = [
    'ret1_atr','ret3_atr','ema9_21_atr','ema21_55_atr','dist_ema21_atr',
    'rsi14','atr_pct','body_pct','close_pos','upper_wick','lower_wick',
    'bb_z','rel_volume','dist_vwap_atr','bar_range_atr','range_location',
]
RAW_COLUMNS = ['time','open','high','low','close','volume']
MIN_BARS = 80


def normalize_ohlcv(raw: pd.DataFrame) -> pd.DataFrame:
    data = raw.copy()
    data.columns = [str(c).lower().strip() for c in data.columns]
    aliases = {'timestamp':'time','datetime':'time','date':'time','tick_volume':'volume','vol':'volume'}
    data = data.rename(columns=aliases)
    if 'volume' not in data: data['volume'] = 0.0
    missing = set(RAW_COLUMNS)-set(data.columns)
    if missing: raise ValueError('CSV is missing columns: ' + ', '.join(sorted(missing)))
    ts = data['time']
    if pd.api.types.is_numeric_dtype(ts):
        # epoch seconds vs milliseconds
        nums = pd.to_numeric(ts,errors='coerce')
        unit = 'ms' if nums.dropna().median() > 1e11 else 's'
        data['time'] = pd.to_datetime(nums, unit=unit, utc=True, errors='coerce')
    else:
        data['time'] = pd.to_datetime(ts, utc=True, errors='coerce')
    for col in RAW_COLUMNS[1:]: data[col] = pd.to_numeric(data[col], errors='coerce')
    data = data.dropna(subset=RAW_COLUMNS).sort_values('time').drop_duplicates('time',keep='last').reset_index(drop=True)
    if data.empty: raise ValueError('No valid OHLCV rows.')
    if ((data['high'] < data[['open','close','low']].max(axis=1)) | (data['low'] > data[['open','close','high']].min(axis=1)) | (data['volume'] < 0)).any():
        raise ValueError('Invalid candle: high/low/open/close or volume is inconsistent.')
    return data


def features_from_raw(data: pd.DataFrame) -> pd.DataFrame:
    d = data.copy()
    close, high, low, op = d.close, d.high, d.low, d.open
    prev = close.shift(1)
    tr = pd.concat([high-low,(high-prev).abs(),(low-prev).abs()],axis=1).max(axis=1)
    d['atr'] = tr.ewm(alpha=1/14,adjust=False).mean()
    atr = d['atr'].replace(0,np.nan)
    d['ema9'] = close.ewm(span=9,adjust=False).mean()
    d['ema21'] = close.ewm(span=21,adjust=False).mean()
    d['ema55'] = close.ewm(span=55,adjust=False).mean()
    diff = close.diff()
    up = diff.clip(lower=0).ewm(alpha=1/14,adjust=False).mean()
    down = (-diff).clip(lower=0).ewm(alpha=1/14,adjust=False).mean()
    rs = up / down.replace(0,np.nan)
    d['rsi14'] = (100-100/(1+rs)).fillna(50)
    ma20 = close.rolling(20,min_periods=20).mean()
    sd20 = close.rolling(20,min_periods=20).std(ddof=0).replace(0,np.nan)
    d['bb_z'] = (close-ma20)/sd20
    vavg = d.volume.shift(1).rolling(20,min_periods=20).mean().replace(0,np.nan)
    d['rel_volume'] = (d.volume/vavg).replace([np.inf,-np.inf],np.nan).fillna(1.0).clip(0,30)
    # Rolling proxy. Not exchange-wide session VWAP.
    v50 = d.volume.rolling(50,min_periods=20).sum().replace(0,np.nan)
    d['rolling_vwap'] = ((high+low+close)/3*d.volume).rolling(50,min_periods=20).sum()/v50
    d['rolling_vwap'] = d['rolling_vwap'].fillna(d.ema21)
    d['hi20prev'] = high.shift(1).rolling(20,min_periods=20).max()
    d['lo20prev'] = low.shift(1).rolling(20,min_periods=20).min()
    cr = (high-low).replace(0,np.nan)
    d['ret1_atr'] = (close-prev)/atr
    d['ret3_atr'] = (close-close.shift(3))/atr
    d['ema9_21_atr'] = (d.ema9-d.ema21)/atr
    d['ema21_55_atr'] = (d.ema21-d.ema55)/atr
    d['dist_ema21_atr'] = (close-d.ema21)/atr
    d['atr_pct'] = d.atr/close*100
    d['body_pct'] = (close-op).abs()/cr
    d['close_pos'] = (close-low)/cr
    d['upper_wick'] = (high-pd.concat([op,close],axis=1).max(axis=1))/cr
    d['lower_wick'] = (pd.concat([op,close],axis=1).min(axis=1)-low)/cr
    d['dist_vwap_atr'] = (close-d.rolling_vwap)/atr
    d['bar_range_atr'] = (high-low)/atr
    d['range_location'] = (close-d.lo20prev)/(d.hi20prev-d.lo20prev).replace(0,np.nan)
    d['prev_open'] = op.shift(1)
    d['prev_close'] = close.shift(1)
    d['prev_high'] = high.shift(1)
    d['prev_low'] = low.shift(1)
    d['prev_vwap'] = d.rolling_vwap.shift(1)
    d['fvg_bull'] = (low>high.shift(2)) & ((low-high.shift(2)) > d.atr*0.08)
    d['fvg_bear'] = (high<low.shift(2)) & ((low.shift(2)-high) > d.atr*0.08)
    d = d.replace([np.inf,-np.inf],np.nan)
    return d
