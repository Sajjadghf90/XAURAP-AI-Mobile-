from __future__ import annotations
import hmac
import io
import json
import os
from pathlib import Path
import threading
from contextlib import asynccontextmanager
import pandas as pd
from fastapi import FastAPI, HTTPException, UploadFile, File, Depends, Header, Request
from fastapi.responses import HTMLResponse
from starlette.concurrency import run_in_threadpool
from pydantic import BaseModel, Field, model_validator
from .store import Storage
from .model import train_model,save_model,load_model,evaluate_latest
from .features import normalize_ohlcv
from .csv_upload import parse_csv_upload
from .methods import METHODS,EXTERNAL_ONLY, evaluate_pine_votes

ROOT=Path(__file__).resolve().parents[1]
DATA=Path(os.environ.get('XAURAP_DATA_DIR',str(ROOT/'data')))
WEBHOOK_TOKEN=os.environ.get('XAURAP_WEBHOOK_TOKEN','')
ADMIN_KEY=os.environ.get('XAURAP_ADMIN_KEY','')
SPREAD=float(os.environ.get('XAURAP_SPREAD_PRICE','0.30'))
THRESHOLD=float(os.environ.get('XAURAP_PROB_THRESHOLD','0.56'))
MODEL_LOCK=threading.RLock()
STATE={'store':None,'model':None}

@asynccontextmanager
async def lifespan(app:FastAPI):
    if not WEBHOOK_TOKEN or len(WEBHOOK_TOKEN)<20 or WEBHOOK_TOKEN.startswith('REPLACE_') or not ADMIN_KEY or len(ADMIN_KEY)<20 or ADMIN_KEY.startswith('REPLACE_') or WEBHOOK_TOKEN==ADMIN_KEY:
        raise RuntimeError('Set unique XAURAP_WEBHOOK_TOKEN and XAURAP_ADMIN_KEY, each at least 20 characters.')
    DATA.mkdir(parents=True,exist_ok=True)
    STATE['store']=Storage(DATA/'events.sqlite3')
    STATE['model']=load_model(DATA)
    yield

app=FastAPI(title='XAURAP AI External Decision Engine',version='1.0.0',lifespan=lifespan)

class Candle(BaseModel):
    version: int = 1
    symbol: str = Field(min_length=2,max_length=45,pattern=r'^[A-Za-z0-9_:.\-]+$')
    timeframe: str = Field(min_length=1,max_length=8,pattern=r'^[0-9A-Za-z]+$')
    time: int=Field(gt=0) # TradingView time_close in epoch milliseconds
    open: float; high: float; low: float; close: float
    volume: float=Field(default=0,ge=0)
    rapid_signal: str=Field(default='NONE',pattern=r'^(NONE|BUY|SELL)$')
    rapid_score: float=Field(default=0,ge=0,le=100)
    atr_tv: float|None=None
    rsi_tv: float|None=None
    trend_bias_tv: int|None=None
    selected_method_tv: str|None=None
    method_votes: str=Field(default="",max_length=135,pattern=r"^(?:$|(?:-1|0|1)(?:;(?:-1|0|1)){44})$")
    @model_validator(mode='after')
    def validate_prices(self):
        import math
        nums=[self.open,self.high,self.low,self.close,self.volume]
        if not all(math.isfinite(v) for v in nums): raise ValueError('Nonfinite prices')
        if self.low>min(self.open,self.close,self.high) or self.high<max(self.open,self.close,self.low):
            raise ValueError('Inconsistent OHLC')
        return self

def admin_guard(x_admin_key:str|None=Header(default=None)):
    if not x_admin_key or not hmac.compare_digest(x_admin_key,ADMIN_KEY):
        raise HTTPException(401,'Invalid admin key')

@app.get('/health')
def health():
    return {'ok':True,'model_trained':STATE['model'] is not None}

@app.get('/',response_class=HTMLResponse)
def homepage():
    return (Path(__file__).parent/'static'/'index.html').read_text(encoding='utf-8')

@app.post('/hooks/tradingview/{token}')
def tv_hook(token:str,candle:Candle):
    if not hmac.compare_digest(token,WEBHOOK_TOKEN): raise HTTPException(401,'Webhook token invalid')
    if candle.version!=1: raise HTTPException(422,'Unsupported webhook version')
    store=STATE['store']
    is_new=store.add_bar(candle)
    if not is_new:
        return {'accepted':True,'duplicate':True,'decision':store.decision_for(candle.symbol,candle.timeframe,candle.time)}
    rows=store.recent(candle.symbol,candle.timeframe,asof_time=candle.time)
    # Reject silent missing-candle histories (weekend/long-market closures excepted).
    minutes = int(candle.timeframe) if candle.timeframe.isdigit() else (1440 if candle.timeframe in ('D','1D') else 10080 if candle.timeframe in ('W','1W') else 0)
    irregular = False
    if minutes and len(rows)>1:
        deltas=[rows[i]['time']-rows[i-1]['time'] for i in range(max(1,len(rows)-39),len(rows))]
        irregular=any((gap>minutes*60_000*1.5 and gap<12*3600*1000) for gap in deltas)
    with MODEL_LOCK:
        trained=STATE['model']
        if trained is not None and minutes and abs(trained.get('bar_seconds',minutes*60)-minutes*60) > max(60,minutes*60*0.05):
            decision={'action':'WAIT','reason':'Incoming chart timeframe does not match training CSV timeframe','candidates':[]}
        elif irregular:
            decision={'action':'WAIT','reason':'Missing alerts / irregular OHLCV bar history in recent window; repair feed before trusting model','candidates':[]}
        elif trained is None:
            decision={'action':'WAIT','reason':'Train AI on real XAUUSD OHLCV CSV before trusting model decisions','candidates':[]}
        else:
            try: decision=evaluate_latest(pd.DataFrame(rows),trained,spread_price=SPREAD,threshold=THRESHOLD)
            except ValueError as e:decision={'action':'WAIT','reason':str(e),'candidates':[]}
    # 45-method Pine router is online-evaluated only from MATURED past votes.
    pine_router = evaluate_pine_votes(pd.DataFrame(rows), SPREAD)
    decision['pine_method_router'] = pine_router
    if decision['action'] in ('BUY','SELL') and pine_router.get('active') and pine_router.get('direction') != decision['action']:
        decision['reason']='AI ML and matured Pine methodology selector disagree; no trade'
        decision['action']='WAIT'
        decision.pop('entry_reference',None)
        decision.pop('sl_reference',None)
        decision.pop('tp_reference',None)
    decision['rapid_signal_from_tv']=candle.rapid_signal
    decision['rapid_score_from_tv']=candle.rapid_score
    decision['ai_feedback_to_pine']=False
    store.add_decision(candle.symbol,candle.timeframe,candle.time,decision)
    return {'accepted':True,'duplicate':False,'decision':decision}

@app.get('/api/status',dependencies=[Depends(admin_guard)])
def status():
    report_path=DATA/'training_report.json'
    report=json.loads(report_path.read_text(encoding='utf-8')) if report_path.exists() else None
    return {'model_trained':STATE['model'] is not None,'data':STATE['store'].stats(),'report':report,'methods':{k:{'name_fa':v[0],'implementation':v[1]} for k,v in METHODS.items()},'external_only':EXTERNAL_ONLY, 'pine_registry_45':json.loads((Path(__file__).parent/'methods_45_manifest.json').read_text(encoding='utf-8'))}

@app.get('/api/decisions',dependencies=[Depends(admin_guard)])
def decisions(limit:int=50):
    return STATE['store'].last_decisions(min(max(limit,1),200))

@app.post('/api/train',dependencies=[Depends(admin_guard)])
async def train_from_uploaded_csv(file:UploadFile=File(...)):
    if not file.filename or not file.filename.lower().endswith('.csv'):raise HTTPException(415,'Upload a CSV file')
    contents=await file.read(12*1024*1024+1)
    if len(contents)>12*1024*1024: raise HTTPException(413,'Maximum CSV size is 12 MB')
    try:
        df=parse_csv_upload(contents)
        # Render Free has only 512 MiB of RAM. Bound training to recent completed candles.
        if len(df)>4500:
            df=df.tail(4500).copy()
        model,report=await run_in_threadpool(train_model,df)
        with MODEL_LOCK:
            save_model(model,report,DATA)
            STATE['model']=model
            # Old pre-training CSV records must not remain visible after training.
            STATE['store'].purge_manual_untrained()
        return report
    except (ValueError,KeyError,UnicodeDecodeError,pd.errors.ParserError) as e:
        raise HTTPException(422,str(e))

@app.post('/api/analyze_csv',dependencies=[Depends(admin_guard)])
async def analyze_latest_csv(file:UploadFile=File(...)):
    """Mobile Basic mode: analyze last CLOSED candle in a manually uploaded CSV."""
    if not file.filename or not file.filename.lower().endswith('.csv'):
        raise HTTPException(415,'Upload a CSV file')
    payload=await file.read(12*1024*1024+1)
    if len(payload)>12*1024*1024:
        raise HTTPException(413,'Maximum CSV size is 12 MB')
    try:
        candles=normalize_ohlcv(parse_csv_upload(payload))
        if len(candles)<80:
            raise ValueError('At least 80 closed bars are required for an analysis')
        timestamp=int(candles.time.iloc[-1].value//1_000_000)
        steps=candles.time.diff().dt.total_seconds().dropna()
        interval=int(round(float(steps.median()))) if len(steps) else 0
        with MODEL_LOCK:
            trained=STATE['model']
            if trained is None:
                result={'action':'WAIT','reason':'No trained AI model; upload at least 700 real historical closed bars for training','candidates':[]}
            elif interval<=0 or abs(interval-trained.get('bar_seconds',0))>max(60,interval*0.05):
                result={'action':'WAIT','reason':'Uploaded CSV timeframe differs from model training timeframe','candidates':[]}
            else:
                result=await run_in_threadpool(evaluate_latest,candles,trained,SPREAD,THRESHOLD)
        # The CSV is uploaded by the user, not a real-time feed. Make this unambiguous.
        result=dict(result)
        result['source']='MANUAL_CSV'
        result['bar_time_utc']=candles.time.iloc[-1].isoformat()
        result['bar_count']=len(candles)
        result['is_live_feed']=False
        import datetime
        age_s=(datetime.datetime.now(datetime.timezone.utc)-candles.time.iloc[-1].to_pydatetime()).total_seconds()
        result['age_seconds']=round(age_s)
        result['stale_warning']='The last bar is over 2 hours old; this is historical analysis, not a live trading signal' if age_s>7200 else 'Uploaded data may be delayed; validate current market price before considering any trade'
        STATE['store'].add_decision('XAUUSD-MANUAL',str(interval),timestamp,result,replace=True)
        saved=STATE['store'].decision_for('XAUUSD-MANUAL',str(interval),timestamp)
        if saved is None or saved.get('reason') != result.get('reason'):
            raise HTTPException(500, 'Manual result could not be verified in storage')
        return result
    except (ValueError,KeyError,UnicodeDecodeError,pd.errors.ParserError) as exc:
        raise HTTPException(422,str(exc))
