import json
import sqlite3
from pathlib import Path

class Storage:
    def __init__(self,path:Path):
        path.parent.mkdir(parents=True,exist_ok=True)
        self.path=path
        with self.conn() as c:
            c.execute('''CREATE TABLE IF NOT EXISTS bars (symbol TEXT, timeframe TEXT, time INTEGER, open REAL, high REAL, low REAL, close REAL, volume REAL, rapid_signal TEXT, rapid_score REAL, method_votes TEXT, PRIMARY KEY(symbol,timeframe,time))''')
            c.execute('''CREATE TABLE IF NOT EXISTS decisions (id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT, timeframe TEXT, time INTEGER, action TEXT, payload TEXT, UNIQUE(symbol,timeframe,time))''')
    def conn(self):
        c=sqlite3.connect(self.path,timeout=10)
        c.row_factory=sqlite3.Row
        return c
    def add_bar(self,p):
        vals=(p.symbol,p.timeframe,p.time,p.open,p.high,p.low,p.close,p.volume,p.rapid_signal,p.rapid_score,getattr(p,"method_votes",""))
        with self.conn() as c:
            result=c.execute('INSERT OR IGNORE INTO bars VALUES (?,?,?,?,?,?,?,?,?,?,?)',vals)
            return result.rowcount==1
    def recent(self,symbol,timeframe,limit=350,asof_time=None):
        with self.conn() as c:
            return [dict(r) for r in reversed(c.execute('SELECT * FROM bars WHERE symbol=? AND timeframe=? AND time <= ? ORDER BY time DESC LIMIT ?', (symbol,timeframe,asof_time if asof_time is not None else 9223372036854775807,limit)).fetchall())]
    def add_decision(self,symbol,tf,timestamp,decision,replace=False):
        # Manual CSV analysis can be repeated for the same last candle after training.
        # Keep TradingView webhook decisions immutable; only explicitly requested
        # manual re-analysis may update an existing (symbol, timeframe, time) row.
        sql = 'INSERT INTO decisions(symbol,timeframe,time,action,payload) VALUES(?,?,?,?,?)'
        if replace:
            sql += ' ON CONFLICT(symbol,timeframe,time) DO UPDATE SET action=excluded.action, payload=excluded.payload'
        else:
            sql = 'INSERT OR IGNORE INTO decisions(symbol,timeframe,time,action,payload) VALUES(?,?,?,?,?)'
        with self.conn() as c:
            c.execute(sql,(symbol,tf,timestamp,decision['action'],json.dumps(decision,ensure_ascii=False)))
    def decision_for(self,symbol,tf,timestamp):
        with self.conn() as c:
            r=c.execute('SELECT payload FROM decisions WHERE symbol=? AND timeframe=? AND time=?',(symbol,tf,timestamp)).fetchone()
        return json.loads(r['payload']) if r else None
    def last_decisions(self,limit=50):
        with self.conn() as c:
            rows=c.execute('SELECT symbol,timeframe,time,action,payload FROM decisions ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
        return [dict(symbol=r['symbol'],timeframe=r['timeframe'],time=r['time'],**json.loads(r['payload'])) for r in rows]
    def stats(self):
        with self.conn() as c:
            return {'bars':c.execute('SELECT COUNT(*) FROM bars').fetchone()[0], 'decisions':c.execute('SELECT COUNT(*) FROM decisions').fetchone()[0]}
