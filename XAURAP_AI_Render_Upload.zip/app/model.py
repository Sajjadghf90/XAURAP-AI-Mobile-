"""Offline supervised classifier. Chronological holdouts and horizon embargo; no training on live synthetic data."""
from __future__ import annotations
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.isotonic import IsotonicRegression
from .features import FEATURE_COLUMNS, MIN_BARS, normalize_ohlcv, features_from_raw
from .methods import METHODS, candidates

MIN_TRAIN_EVENTS = 60
MIN_METHOD_EVENTS = 15
RISK_ATR = 1.2
REWARD_R = 1.8
HORIZON = 8


def input_vector(r:pd.Series, method:str,side:int):
    vals = [float(r[k]) for k in FEATURE_COLUMNS]
    if not np.isfinite(vals).all(): raise ValueError('Feature history is incomplete')
    return vals+[float(side)]+[1. if name==method else 0. for name in METHODS]


def bracket_outcome(d:pd.DataFrame,i:int,side:int,horizon:int=HORIZON):
    """Conservative intrabar ambiguity = loss. Entry=signal close, future starts next bar."""
    entry,atr = float(d.iloc[i].close),float(d.iloc[i].atr)
    risk = max(atr*RISK_ATR, 0.00001)
    for j in range(i+1,min(i+horizon+1,len(d))):
        bar = d.iloc[j]
        tp = entry+side*risk*REWARD_R
        sl = entry-side*risk
        stop = (bar.low<=sl) if side==1 else (bar.high>=sl)
        take = (bar.high>=tp) if side==1 else (bar.low<=tp)
        if stop: return 0  # stop-first when both touched; slippage not measured
        if take: return 1
    return 0 # no take within horizon = not a winning bracket


def build_samples(d:pd.DataFrame, from_i:int,to_i:int,horizon:int):
    X=[];Y=[];meta=[]
    for i in range(max(from_i,MIN_BARS),min(to_i,len(d)-horizon)):
        r=d.iloc[i]
        for method,side in candidates(r):
            try: x=input_vector(r,method,side)
            except ValueError: continue
            X.append(x);Y.append(bracket_outcome(d,i,side,horizon));meta.append((i,method,side))
    return np.asarray(X,dtype=float).reshape((-1,len(FEATURE_COLUMNS)+1+len(METHODS))),np.asarray(Y,dtype=int),meta


def train_model(raw:pd.DataFrame, horizon:int=HORIZON) -> tuple[dict,dict]:
    d=features_from_raw(normalize_ohlcv(raw))
    n=len(d)
    bar_seconds=int(round(float(d.time.diff().dt.total_seconds().dropna().median())))
    if bar_seconds<=0: raise ValueError('Invalid time interval')
    if n<700: raise ValueError(f'At least 700 complete bars required; got {n}. Recommend 3000+.')
    a=int(n*.65);b=int(n*.82)
    # Embargo of horizon bars between train/validation and validation/test.
    trX,trY,trMeta=build_samples(d,MIN_BARS,a-horizon,horizon)
    vaX,vaY,vaMeta=build_samples(d,a,b-horizon,horizon)
    teX,teY,teMeta=build_samples(d,b,n-horizon,horizon)
    if len(trY)<MIN_TRAIN_EVENTS or len(np.unique(trY))<2 or len(vaY)<20 or len(teY)<20:
        raise ValueError(f'Insufficient signals/diversity for evaluation: train={len(trY)}, valid={len(vaY)}, test={len(teY)}; use more bars.')
    clf=HistGradientBoostingClassifier(max_iter=75,max_leaf_nodes=13,min_samples_leaf=18,l2_regularization=1.0,random_state=41,early_stopping=False)
    clf.fit(trX,trY)
    cal=None
    if len(np.unique(vaY))==2 and len(vaY)>=40:
        cal=IsotonicRegression(y_min=0.02,y_max=0.98,out_of_bounds='clip')
        cal.fit(clf.predict_proba(vaX)[:,1],vaY)
    def predict(xx):
        pp=clf.predict_proba(xx)[:,1]
        return cal.predict(pp) if cal is not None else pp
    p=predict(teX)
    # Evaluation is not actual account P&L; assume 1R stop, 1.8R win, simplified costs.
    returns=np.where(teY==1,REWARD_R,-1.)
    details={}
    for method in METHODS:
        inds=[k for k,(_,m,_) in enumerate(teMeta) if m==method]
        if inds:
            vals=returns[inds]; details[method]={'events':len(inds),'win_rate':round(float(np.mean(teY[inds])),4),'mean_bracket_R_before_costs':round(float(np.mean(vals)),4)}
    result={'bar_seconds':bar_seconds,'rows':n,'events_train':len(trY),'events_valid':len(vaY),'events_test':len(teY),
            'test_bracket_win_rate':round(float(np.mean(teY)),4),
            'test_brier':round(float(np.mean((p-teY)**2)),4),
            'calibration': 'validation_isotonic' if cal is not None else 'uncalibrated',
            'test_methods':details,
            'warning':'Backtest labels assume signal-close entry, idealized fills, conservative same-bar stop first, and no spread/slippage. Not verified profitability.'}
    counts={method:sum(1 for _,m,_ in trMeta if m==method) for method in METHODS}
    result['train_events_by_method']=counts
    artifact={'classifier':clf,'calibrator':cal,'feature_columns':FEATURE_COLUMNS,'methods':list(METHODS),'method_event_counts':counts,'bar_seconds':bar_seconds,'horizon':horizon,'version':1}
    return artifact,result


def save_model(artifact:dict,report:dict,folder:Path):
    folder.mkdir(parents=True,exist_ok=True)
    p=folder/'trained_model.joblib';tmp=folder/'trained_model.joblib.tmp'
    joblib.dump(artifact,tmp);tmp.replace(p)
    (folder/'training_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')


def load_model(folder:Path):
    p=folder/'trained_model.joblib'
    # joblib/pickle must only load artifacts generated locally, never third-party uploads.
    if not p.exists():return None
    obj=joblib.load(p)
    if obj.get('version')!=1 or obj.get('feature_columns')!=FEATURE_COLUMNS or obj.get('methods')!=list(METHODS):
        raise ValueError('Model schema mismatch: retrain with this release.')
    return obj


def evaluate_latest(raw:pd.DataFrame,artifact:dict,spread_price:float=0.30, threshold:float=0.56):
    d=features_from_raw(normalize_ohlcv(raw))
    if len(d)<MIN_BARS: return {'action':'WAIT','reason':f'Warm-up: {len(d)}/{MIN_BARS} completed bars','candidates':[]}
    last=d.iloc[-1]
    cs=candidates(last)
    if not cs: return {'action':'WAIT','reason':'No implemented method triggered on this closed bar','candidates':[]}
    scored=[]
    atr=float(last.atr)
    cost_R=max(0.,spread_price)/max(atr*RISK_ATR,1e-8)
    for method,side in cs:
        if artifact.get('method_event_counts',{}).get(method,0)<MIN_METHOD_EVENTS: continue
        try: x=np.asarray([input_vector(last,method,side)],dtype=float)
        except ValueError: continue
        p=float(artifact['classifier'].predict_proba(x)[0,1]);cal=artifact.get('calibrator')
        if cal is not None:p=float(cal.predict([p])[0])
        ev=p*REWARD_R-(1-p)-cost_R
        scored.append({'method':method,'direction':'BUY' if side==1 else 'SELL','estimated_win_probability':round(p,4),
            'estimated_expected_R_after_spread_proxy':round(ev,4),'cost_R_proxy':round(cost_R,4)})
    scored.sort(key=lambda x:x['estimated_expected_R_after_spread_proxy'],reverse=True)
    if not scored:return {'action':'WAIT','reason':'Active strategies lack 15 historical training examples or features are unavailable','candidates':[]}
    top=scored[0]
    if top['estimated_win_probability']<threshold or top['estimated_expected_R_after_spread_proxy']<=0:
        return {'action':'WAIT','reason':'No candidate exceeds minimum model score and proxy expected R', 'best_method':top['method'],'candidates':scored}
    side=1 if top['direction']=='BUY' else -1
    price=float(last.close);risk=atr*RISK_ATR
    return {'action':top['direction'],'reason':'Selected highest expected R among active computational methods',
            'best_method':top['method'],'entry_reference':round(price,5), 'sl_reference':round(price-side*risk,5),
            'tp_reference':round(price+side*risk*REWARD_R,5),'candidates':scored,
            'warning':'Decision support only; broker spread, slippage, news and actual fill are not assured.'}
