"""CSV parser for comma, semicolon, tab and common MT5 export columns.

Clock zone in MT5 exports may be broker-local; treated as UTC in this demo.
"""
from __future__ import annotations
import io
import pandas as pd

def parse_csv_upload(payload: bytes) -> pd.DataFrame:
    try:
        data=pd.read_csv(io.BytesIO(payload), sep=None, engine='python', encoding='utf-8-sig')
    except (ValueError, UnicodeError, pd.errors.ParserError) as exc:
        raise ValueError('CSV unreadable; export as UTF-8 CSV or tab-delimited MT5 history') from exc
    if data.empty:
        raise ValueError('CSV has no rows')
    clean=lambda c: str(c).strip().strip('<>').strip().lower()
    data.columns=[clean(c) for c in data.columns]
    if 'time' in data and 'date' in data:
        # Typical MT5 <DATE> <TIME> split columns (HH:MM:SS in time).
        t=data['time'].astype(str).str.strip()
        if t.str.fullmatch(r'\d{1,2}:\d{2}(?::\d{2})?').mean()>.95:
            data['time']=data['date'].astype(str).str.strip()+' '+t
            data=data.drop(columns=['date'])
    if 'time' not in data and 'date' in data:
        data['time']=data['date']
    if 'volume' not in data:
        if 'tickvol' in data:
            data['volume']=data['tickvol']
        elif 'vol' in data:
            data['volume']=data['vol']
        elif 'real_volume' in data:
            data['volume']=data['real_volume']
    if 'time' not in data:
        raise ValueError('CSV needs time column or MT5 DATE/TIME columns')
    # pandas recognizes yyyy.mm.dd, but make the format unambiguous.
    data['time']=data['time'].astype(str).str.replace('.', '-', regex=False)
    return data
