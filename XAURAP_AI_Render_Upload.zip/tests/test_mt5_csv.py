import pandas as pd
from app.csv_upload import parse_csv_upload
from app.features import normalize_ohlcv
def test_mt5_tab_export():
    raw='<DATE>\t<TIME>\t<OPEN>\t<HIGH>\t<LOW>\t<CLOSE>\t<TICKVOL>\n2026.10.12\t09:30:00\t4000\t4001\t3999\t4000.5\t500\n2026.10.12\t09:35:00\t4000.5\t4003\t4000\t4002\t600\n'
    df=normalize_ohlcv(parse_csv_upload(raw.encode()))
    assert len(df)==2
    assert df.time.iloc[1].minute==35
    assert float(df.volume.iloc[1])==600
def test_csv_semicolon_format():
    raw='time;open;high;low;close;volume\n2026-10-12 09:30:00;4000;4001;3999;4000.5;500\n2026-10-12 09:35:00;4000.5;4003;4000;4002;600'
    assert len(normalize_ohlcv(parse_csv_upload(raw.encode())))==2
