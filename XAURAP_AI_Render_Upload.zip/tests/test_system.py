import os
import tempfile
from pathlib import Path
os.environ['XAURAP_WEBHOOK_TOKEN']='test_token_long_and_unique_123456'
os.environ['XAURAP_ADMIN_KEY']='test_admin_key_long_and_unique_123'
os.environ['XAURAP_DATA_DIR']=str(Path(tempfile.mkdtemp())/'db')
import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient
from app.features import normalize_ohlcv, features_from_raw
from app.methods import candidates
from app.model import train_model,save_model,load_model,evaluate_latest,bracket_outcome,MIN_BARS
from app.main import app


def example_data(n=1700,seed=24):
    rng=np.random.default_rng(seed)
    # Synthetic validation fixture, NEVER represented as real gold market data.
    steps=rng.standard_normal(n)*1.8+np.sin(np.arange(n)/26)*0.46
    close=3000+np.cumsum(steps)
    op=np.r_[close[0],close[:-1]]
    high=np.maximum(op,close)+rng.uniform(0.2,1.9,n)
    low=np.minimum(op,close)-rng.uniform(0.2,1.9,n)
    return pd.DataFrame({'time':pd.date_range('2025-01-01',periods=n,freq='5min',tz='UTC'),
     'open':op,'high':high,'low':low,'close':close,'volume':rng.integers(100,1000,n)})


def test_causal_features_not_changed_by_future_bars():
    d=normalize_ohlcv(example_data(200))
    before=features_from_raw(d.iloc[:150]).iloc[120]
    after=features_from_raw(d).iloc[120]
    for k in ['atr','rsi14','bb_z','hi20prev','lo20prev','ema9','rolling_vwap']:
        assert np.isclose(before[k],after[k],equal_nan=True)


def test_intrabar_ambiguous_result_is_loss():
    d=pd.DataFrame([{'close':100.,'atr':1.,'high':101.,'low':99.},
                    {'close':100.,'atr':1.,'high':103.,'low':98.}])
    assert bracket_outcome(d,0,1,horizon=1)==0
    assert bracket_outcome(d,0,-1,horizon=1)==0


def test_real_ml_training_and_reload(tmp_path):
    artifact,report=train_model(example_data())
    assert report['events_test']>=20
    assert 0<=report['test_brier']<=1
    assert report['events_train']>report['events_valid']
    save_model(artifact,report,tmp_path)
    restored=load_model(tmp_path)
    decision=evaluate_latest(example_data(800),restored)
    assert decision['action'] in ('BUY','SELL','WAIT')
    if decision['action']!='WAIT':
        assert decision['best_method'] in restored['methods']


def test_invalid_candles_rejected():
    d=example_data(100)
    d.loc[0,'low']=d.loc[0,'high']+1
    with pytest.raises(ValueError):normalize_ohlcv(d)


def test_requires_real_training_before_ai_signals():
    with TestClient(app) as client:
        data={'version':1,'symbol':'XAUUSD','timeframe':'5','time':1750000000000,
              'open':3330.,'high':3334.,'low':3328.,'close':3333.,'volume':1400.,
              'rapid_signal':'BUY','rapid_score':91.}
        assert client.post('/hooks/tradingview/wrong',json=data).status_code==401
        assert client.get('/api/decisions').status_code==401
        r=client.post('/hooks/tradingview/test_token_long_and_unique_123456',json=data)
        assert r.status_code==200,r.text
        assert r.json()['decision']['action']=='WAIT'
        assert r.json()['decision']['rapid_signal_from_tv']=='BUY'
        repeated=client.post('/hooks/tradingview/test_token_long_and_unique_123456',json=data)
        assert repeated.json()['duplicate'] is True
        r=client.get('/api/decisions',headers={'X-Admin-Key':'test_admin_key_long_and_unique_123'})
        assert len(r.json())==1
        invalid={**data,'time':1750000300000,'high':3300.}
        assert client.post('/hooks/tradingview/test_token_long_and_unique_123456',json=invalid).status_code==422


def test_end_to_end_api_training_and_live_bar_flow():
    history=example_data(1700,seed=55)
    with TestClient(app) as client:
        hdr={'X-Admin-Key':'test_admin_key_long_and_unique_123'}
        response=client.post('/api/train',files={'file':('real_format.csv',history.to_csv(index=False).encode('utf-8'),'text/csv')},headers=hdr)
        assert response.status_code==200,response.text
        assert response.json()['events_test']>=20
        status=client.get('/api/status',headers=hdr).json()
        assert status['model_trained']
        assert len(status['pine_registry_45'])==45
        # 100 recent complete bars from the same synthetic fixture are ingested without gaps.
        for row in history.iloc[-100:].itertuples():
            c={'version':1,'symbol':'XAUUSD','timeframe':'5','time':int(row.time.value//1_000_000),
             'open':row.open,'high':row.high,'low':row.low,'close':row.close,'volume':row.volume}
            r=client.post('/hooks/tradingview/test_token_long_and_unique_123456',json=c)
            assert r.status_code==200,r.text
        d=client.get('/api/decisions',headers=hdr).json()
        assert d[0]['action'] in ['BUY','SELL','WAIT']
        assert d[0]['reason']!='Train AI on real XAUUSD OHLCV CSV before trusting model decisions'
        assert client.get('/api/status',headers=hdr).json()['data']['bars']>=100


def test_out_of_order_webhook_does_not_look_ahead():
    from app.store import Storage
    store=Storage(Path(tempfile.mkdtemp())/'outoforder.sqlite')
    class C:
        def __init__(self,time,close):
            self.symbol='XAUUSD'; self.timeframe='5'; self.time=time
            self.open=close;self.high=close+1;self.low=close-1;self.close=close
            self.volume=30.;self.rapid_signal='NONE';self.rapid_score=0.
    store.add_bar(C(1000,3.0))
    store.add_bar(C(3000,9.0))
    store.add_bar(C(2000,5.0))
    assert [r['time'] for r in store.recent('XAUUSD','5',asof_time=2000)]==[1000,2000]


def test_pine_votes_router_filters_external_and_matures_correctly():
    from app.methods import evaluate_pine_votes
    r=example_data(120)
    ext_only=['0']*45;ext_only[14]='1';r['method_votes']=';'.join(ext_only)
    out=evaluate_pine_votes(r)
    assert out['active'] is False
    r['method_votes']=';'.join(['1' if i==39 else '0' for i in range(45)])
    out=evaluate_pine_votes(r)
    assert isinstance(out['active'],bool)
    assert 'tested' in out or out['active'] is False


def test_mobile_csv_analysis_requires_admin_and_never_mislabels_as_live():
    history=example_data(1700,seed=77)
    with TestClient(app) as client:
        hdr={'X-Admin-Key':'test_admin_key_long_and_unique_123'}
        csv=history.to_csv(index=False).encode('utf-8')
        response=client.post('/api/analyze_csv',files={'file':('gold.csv',csv,'text/csv')})
        assert response.status_code==401
        trained=client.post('/api/train',files={'file':('gold.csv',csv,'text/csv')},headers=hdr)
        assert trained.status_code==200,trained.text
        response=client.post('/api/analyze_csv',files={'file':('gold.csv',csv,'text/csv')},headers=hdr)
        assert response.status_code==200,response.text
        analysis=response.json()
        assert analysis['source']=='MANUAL_CSV'
        assert analysis['is_live_feed'] is False
        assert analysis['action'] in ['BUY','SELL','WAIT']
        assert 'bar_time_utc' in analysis
        assert 'stale_warning' in analysis
        short=history.iloc[-50:].to_csv(index=False).encode('utf-8')
        assert client.post('/api/analyze_csv',files={'file':('gold.csv',short,'text/csv')},headers=hdr).status_code==422


def test_manual_reanalysis_overwrites_old_decision_without_changing_live_decisions(tmp_path):
    from app.store import Storage
    store=Storage(tmp_path/'events.sqlite')
    old={'action':'WAIT','reason':'No trained AI model; upload at least 700 bars'}
    fresh={'action':'WAIT','reason':'No candidate exceeds minimum model score', 'best_method':'BREAKOUT_20'}
    store.add_decision('XAUUSD-MANUAL','300',1234567,old,replace=True)
    store.add_decision('XAUUSD-MANUAL','300',1234567,fresh,replace=True)
    assert store.stats()['decisions']==1
    assert store.last_decisions()[0]['reason']==fresh['reason']
    assert store.last_decisions()[0]['best_method']=='BREAKOUT_20'
    store.add_decision('XAUUSD','5',1234567,old)
    store.add_decision('XAUUSD','5',1234567,fresh)
    assert store.stats()['decisions']==2
    assert store.decision_for('XAUUSD','5',1234567)==old


def test_train_discards_pretraining_csv_rows_and_keeps_real_webhook_history(tmp_path):
    from app.store import Storage
    store=Storage(tmp_path/'events.sqlite')
    store.add_decision('XAUUSD-MANUAL','300',1234,{'action':'WAIT','reason':'No trained AI model'},replace=True)
    store.add_decision('XAUUSD','5',1234,{'action':'WAIT','reason':'No trained AI model'})
    assert store.purge_manual_untrained()==1
    assert len(store.last_decisions())==1
    assert store.last_decisions()[0]['symbol']=='XAUUSD'


def test_manual_latest_replaces_stale_other_key_and_saves_new_model_result(tmp_path):
    from app.store import Storage
    store=Storage(tmp_path/'events.sqlite')
    store.add_decision('XAUUSD-MANUAL','300',1234,{'action':'WAIT','reason':'No trained AI model'},replace=True)
    store.add_decision('XAUUSD-MANUAL','300',4321,{'action':'WAIT','reason':'No candidate exceeds model threshold','best_method':'BREAKOUT_20'},replace=True)
    rows=store.last_decisions()
    assert len(rows)==1
    assert rows[0]['time']==4321
    assert rows[0]['reason']=='No candidate exceeds model threshold'
    assert rows[0]['best_method']=='BREAKOUT_20'


def test_pretrain_analyze_then_train_then_analyze_endpoint_roundtrip(tmp_path):
    # Full server test with real fixture shape; reproduces exact observed action order.
    from app.main import STATE
    sample=example_data(900,seed=91).to_csv(index=False).encode()
    hdr={'X-Admin-Key':'test_admin_key_long_and_unique_123'}
    with TestClient(app) as client:
        no_model=client.post('/api/analyze_csv',files={'file':('xau.csv',sample,'text/csv')},headers=hdr)
        # Earlier tests may have trained the shared STATE; explicitly remove model during pretrain leg.
        # Ensure one old pre-training record exists regardless of previous tests.
        STATE['store'].add_decision('XAUUSD-MANUAL','300',999999,{'action':'WAIT','reason':'No trained AI model'},replace=True)
        report=client.post('/api/train',files={'file':('xau.csv',sample,'text/csv')},headers=hdr)
        assert report.status_code==200,report.text
        after_train=client.get('/api/decisions',headers=hdr).json()
        assert all('No trained AI model' not in d['reason'] for d in after_train if d['symbol']=='XAUUSD-MANUAL')
        latest=client.post('/api/analyze_csv',files={'file':('xau.csv',sample,'text/csv')},headers=hdr)
        assert latest.status_code==200,latest.text
        stored=client.get('/api/decisions',headers=hdr).json()
        assert stored[0]['reason']==latest.json()['reason']
        assert stored[0]['action']==latest.json()['action']
